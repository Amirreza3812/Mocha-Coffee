import React from "react";

const Document = () => {
  return <h1>Document</h1>;
};

export default Document;
