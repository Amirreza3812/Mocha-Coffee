import React from "react";

const Calender = () => {
  return <h1>Calender</h1>;
};

export default Calender;
